package com.numetry.www.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.numetry.www.entity.Place;

public interface PlaceRepository extends JpaRepository<Place, Long> {

}
