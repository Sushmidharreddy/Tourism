package com.numetry.www.entity;

import lombok.Data;

@Data
public class SmsDetails 
{
	private String to;
    private String message;
}
