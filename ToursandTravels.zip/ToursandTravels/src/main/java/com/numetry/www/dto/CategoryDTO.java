package com.numetry.www.dto;

import java.util.Set;

import com.numetry.www.entity.State;

import lombok.Data;

@Data
public class CategoryDTO 
{
	
	
	private String categoryName;
	
//	private State state;
	
	private Set<PlaceDTO> places;

}
