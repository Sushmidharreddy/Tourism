package com.numetry.www.dto;

import java.util.Set;



import lombok.Data;

@Data
public class StateDTO 
{
	private String stateName;

	
	private Set<CategoryDTO> categories;
}
