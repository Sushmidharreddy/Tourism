package com.numetry.www.dto;

import com.numetry.www.entity.Category;

import jakarta.persistence.JoinColumn;
import lombok.Data;

@Data
public class PlaceDTO 
{
	
	
	 private String placeName;
	 
	 private String placeImage;
	 
	 private String nearbyRailwayStation;
	 
	 private String nearbyAirport;
	 
	 private String nearbyBusStop;
	 
	 private String nearbyHotel;
	 

}
