package com.numetry.www;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToursandTravelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
